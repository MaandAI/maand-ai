import { NextRequest, NextResponse } from "next/server";
import { withAuth } from "@/backend/middlewares/auth.middleware";
import dbConnect from "@/lib/mongodb";
import ChatSession from "@/models/ChatSession";

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ sessionId: string }> },
) {
  return withAuth(req, async (req, user) => {
    try {
      await dbConnect();
      const { sessionId } = await params;
      const session = await ChatSession.findOne({
        _id: sessionId,
        userId: user.id,
      });

      if (!session) {
        return NextResponse.json(
          { error: "Session not found" },
          { status: 404 },
        );
      }

      return NextResponse.json({ success: true, data: session });
    } catch (error: any) {
      console.error("Get Session API Error:", error);
      return NextResponse.json(
        { error: "Internal Server Error" },
        { status: 500 },
      );
    }
  });
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ sessionId: string }> },
) {
  return withAuth(req, async (req, user) => {
    try {
      const body = await req.json();
      const updateData: any = {};

      if (body.title !== undefined) updateData.title = body.title;
      if (body.isFavorite !== undefined)
        updateData.isFavorite = body.isFavorite;

      if (Object.keys(updateData).length === 0) {
        return NextResponse.json(
          { error: "No update data provided" },
          { status: 400 },
        );
      }

      await dbConnect();
      const { sessionId } = await params;
      const session = await ChatSession.findOneAndUpdate(
        { _id: sessionId, userId: user.id },
        updateData,
        { new: true },
      );

      if (!session) {
        return NextResponse.json(
          { error: "Session not found" },
          { status: 404 },
        );
      }

      return NextResponse.json({ success: true, data: session });
    } catch (error: any) {
      console.error("Rename Session API Error:", error);
      return NextResponse.json(
        { error: "Internal Server Error" },
        { status: 500 },
      );
    }
  });
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ sessionId: string }> },
) {
  return withAuth(req, async (req, user) => {
    try {
      await dbConnect();
      const { sessionId } = await params;
      const session = await ChatSession.findOneAndDelete({
        _id: sessionId,
        userId: user.id,
      });

      if (!session) {
        return NextResponse.json(
          { error: "Session not found" },
          { status: 404 },
        );
      }

      return NextResponse.json({ success: true, message: "Session deleted" });
    } catch (error: any) {
      console.error("Delete Session API Error:", error);
      return NextResponse.json(
        { error: "Internal Server Error" },
        { status: 500 },
      );
    }
  });
}
